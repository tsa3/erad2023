#include <iostream>
#include <utility>
#include <vector>
#include <string>
#include <map>
#include <omp.h>

using namespace std;

enum {COLOR_TO_WRITE, DIRECTION_TO_TURN, NEXT_STATE};

typedef struct turmite {
    // row and column of the turmite
    pair<uint, uint> position;

    // direction to which the turmite is pointing
    // (UP: 0, RIGHT: 1, DOWN: 2, LEFT: 3)
    uint direction = 0;
    uint current_state = 0;
} turmite;

void printBoard(vector<vector<int>> board) {
    vector<char> colors = {' ', '*'};
    for (auto i : board) {
        for (auto j : i)
            cout << colors[j];
        cout << endl;
    }
}

int main() {
    vector<vector<int>> turns = {{-1,  0},
                                 { 0,  1},
                                 { 1,  0},
                                 { 0, -1}};
    uint time_step = 0, total_steps = 0, turmite_number = 0;
    uint direction = 0, board_rows = 0, board_columns = 0;

    // Given a state and a color, the state transition table outputs a new
    // color, a change in direction and a new state
    map<pair<int, int>, vector<int>> state_table;
    state_table[make_pair(0, 0)] = {1, 1, 0};
    state_table[make_pair(0, 1)] = {1, 1, 1};
    state_table[make_pair(1, 0)] = {0, 0, 0};
    state_table[make_pair(1, 1)] = {0, 0, 1};

    // Creates the board, turmites and positions them on the board
    cin >> board_rows >> board_columns >> total_steps >> turmite_number;
    vector<vector<int>> board(board_rows, vector<int> (board_columns, 0));
    vector<turmite> turmites(turmite_number);
    for (int i = 0; i < turmite_number; i++)
        cin >> turmites[i].position.first >> turmites[i].position.second;

    // Iterates over all steps performing the action of each turmite
    #pragma omp parallel for private(current_color, transition, board, direction, turmites) schedule(dynamic) num_threads(14) omp_proc_bind = spread
    for (int time_step = 0; time_step < total_steps; time_step++) {
        for (int i = 0; i < turmite_number; i++) {
            uint current_color = board[turmites[i].position.first][turmites[i].position.second];
            vector<int> transition = state_table[make_pair(turmites[i].current_state, current_color)];
            board[turmites[i].position.first][turmites[i].position.second] = transition[COLOR_TO_WRITE];
            direction = (direction + transition[DIRECTION_TO_TURN]) % 4;
            turmites[i].position.first  += turns[direction][0];
            turmites[i].position.second += turns[direction][1];
            turmites[i].position.first  %= board.size();
            turmites[i].position.second %= board[0].size();
            turmites[i].current_state = transition[NEXT_STATE];
        }
    }
    printBoard(board);
}
