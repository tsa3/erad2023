#include <stdio.h>
#include <sys/time.h>
#include <stdlib.h>
#include <omp.h>
#include "compute_julia_pixel.h"
#include "write_bmp_header.h"
#define RGB_PRECISION (unsigned long long)3

static double gettime ()
{
  struct timeval t;
  gettimeofday(&t, NULL);
  return (double)t.tv_sec + (double)t.tv_usec/1000000;
}

int main(int argc, char *argv[])
{
  int width, height, max_iterations, write_output;

  if (argc == 5) {
    width = atoi(argv[1]);
    height = atoi(argv[2]);
    max_iterations = atoi(argv[3]);
    write_output = atoi(argv[4]);
  } else {
    scanf("%d", &width);
    scanf("%d", &height);
    scanf("%d", &max_iterations);
    scanf("%d", &write_output);
  }
  printf("Input: %d %d %d %d\n", width, height, max_iterations, write_output);
  unsigned long long size = (unsigned long long)width * (unsigned long long)height * RGB_PRECISION;
  unsigned char *image = malloc(sizeof(unsigned char) * size);
  if (!image) {
    //fprintf(stderr, "couldn't allocate %lld bytes\n", size);
    return 1;
  }
  float tint_bias = 1.0;
  int result = 0;

  //fprintf(stderr, "start computing a julia set of size %lld\n", size);
  double t0 = gettime();

  #pragma omp parallel for private(pixel, result) omp_num_threads = 28
  for (unsigned long long i = 0; i < (unsigned long long)width; i++) {
    for (unsigned long long j = 0; j < (unsigned long long)height; j++) {
      julia_pixel_t pixel = { 0 };
      pixel = create_julia_pixel(i, j,
                                 width, height,
                                 tint_bias,
                                 &image[(unsigned long long)(RGB_PRECISION) * (unsigned long long)((j * (unsigned long long)width) + i)],
                                 max_iterations);
      result = compute_julia_pixel(pixel);
      if (result)
        break;
    }
  }
  unsigned long long accum = 0;

  #pragma omp parallel for omp_num_threads = 28
  for (unsigned long long i = 0; i < size; i++){
    accum += image[i];
  }
  double t1 = gettime();
  printf("Output: %f\n", (float)accum/size);
  //fprintf(stderr, "finish computing in %f seconds, writing output\n", t1-t0);

  if (result) {
    //fprintf(stderr, "couldn't compute all julia pixels\n");
    free(image);
    return 1;
  }

  if (!write_output) {
    //fprintf(stderr, "requested only to compute, finish now\n");
    free(image);
    return 0;
  }

  FILE *fp = fopen("julia.bmp", "w");
  if (!fp) {
    //fprintf(stderr, "couldn't open julia.bmp for writing\n");
    free(image);
    return 1;
  }
  int res = write_bmp_header(fp, width, height);
  if (res) {
    //fprintf(stderr, "couldn't write bmp header\n");
    free(image);
    return 1;
  }
  int elements = fwrite(image, sizeof(char), size, fp);
  if (elements != size) {
    //fprintf(stderr, "couldn't write all pixels\n");
    free(image);
    return 1;
  }
  free(image);
  fclose(fp);
  //fprintf(stderr, "see julia.bmp file\n");
  return 0;
}
