#ifndef _WRITE_BMP_HEADER_H_
#define _WRITE_BMP_HEADER_H_
#include<stdio.h>

int write_bmp_header(FILE * f, int width, int height);

#endif                          //_WRITE_BMP_HEADER_H_
