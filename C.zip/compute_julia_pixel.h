#ifndef _COMPUTE_JULIA_PIXEL_H
#define _COMPUTE_JULIA_PIXEL_H
#include <stdio.h>
#include <math.h>

typedef struct {
  int x;
  int y;
  int width;
  int height;
  float tint_bias;
  unsigned char *rgb;

  int max_iterations;
} julia_pixel_t;

int compute_julia_pixel(julia_pixel_t pixel);
julia_pixel_t create_julia_pixel(int x, int y, int width, int height,
                                 float tint_bias, unsigned char *rgb,
                                 int max_iterations);

#endif                          //_COMPUTE_JULIA_PIXEL_H
