#include "compute_julia_pixel.h"
/*
 * compute_julia_pixel(): compute RBG values of a pixel in a
 *                        particular Julia set image.
 *
 *  In:
 *      (x,y):            pixel coordinates
 *      (width, height):  image dimensions
 *      tint_bias:        a float to "tweak" the tint (1.0 is "no tint")
 *  Out:
 *      rgb: an already-allocated 3-byte array into which R, G, and B
 *           values are written.
 *
 *  Return:
 *      0 in success, -1 on failure
 *
 */

int compute_julia_pixel(julia_pixel_t pixel)
{
  // Check coordinates
  if ((pixel.x < 0) || (pixel.x >= pixel.width) || (pixel.y < 0)
      || (pixel.y >= pixel.height)) {
    fprintf(stderr,
            "Invalid (%d,%d) pixel coordinates in a %d x %d image\n",
            pixel.x, pixel.y, pixel.width, pixel.height);
    return -1;
  }
  // "Zoom in" to a pleasing view of the Julia set
  float X_MIN = -1.6, X_MAX = 1.6, Y_MIN = -0.9, Y_MAX = +0.9;
  float float_y = (Y_MAX - Y_MIN) * (float) pixel.y / pixel.height + Y_MIN;
  float float_x = (X_MAX - X_MIN) * (float) pixel.x / pixel.width + X_MIN;

  // Point that defines the Julia set
  float julia_real = -.79;
  float julia_img = .15;

  // Compute the complex series convergence
  float real = float_y, img = float_x;
  int num_iter = pixel.max_iterations;
  while ((img * img + real * real < 2 * 2) && (num_iter > 0)) {
    float xtemp = img * img - real * real + julia_real;
    real = 2 * img * real + julia_img;
    img = xtemp;
    num_iter--;
  }

  // Paint pixel based on how many iterations were used, using some funky colors
  float color_bias = (float) num_iter / pixel.max_iterations;
  pixel.rgb[0] =
      (num_iter ==
       0 ? 200 : -500.0 * pow(pixel.tint_bias, 1.2) * pow(color_bias,
                                                          1.6));
  pixel.rgb[1] = (num_iter == 0 ? 100 : -255.0 * pow(color_bias, 0.3));
  pixel.rgb[2] =
      (num_iter ==
       0 ? 100 : 255 - 255.0 * pow(pixel.tint_bias, 1.2) * pow(color_bias,
                                                               3.0));

  return 0;
}

julia_pixel_t create_julia_pixel(int x, int y, int width, int height,
                                 float tint_bias, unsigned char *rgb,
                                 int max_iterations)
{
  julia_pixel_t pixel = { 0 };
  pixel.x = x;
  pixel.y = y;
  pixel.width = width;
  pixel.height = height;
  pixel.tint_bias = tint_bias;
  pixel.rgb = rgb;
  pixel.max_iterations = max_iterations;
  return pixel;
}
