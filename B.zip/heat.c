#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>

// determina o índice em um array 1D a partir dos índices de uma matriz
#define I2D(num, r, c) ((r) * (num) + (c))

#define THD_SILVER 8.418e-5 // difusividade térmica da prata
#define PRECISION 1e7       // precisão em 7 casas decimais

/**
 * Computa uma iteração da simulação de transferência de calor.
 */
void heat_conduction_kernel(int nrows, int ncols, double thd, double *temp_in, double *temp_out)
{
    // índices dos pontos central e seus vizinhos na matriz
    int p_center, p_left, p_right, p_up, p_down;
    // derivadas com relação aos eixos x e y
    double d2tdx2, d2tdy2;

    #pragma omp parallel for omp_num_threads = 28 omp_proc_bind = spread
    for (int i = 1; i < nrows - 1; i++)
    {
        for (int j = 1; j < ncols - 1; j++)
        {
            p_center = I2D(ncols, i, j);
            p_left = I2D(ncols, i, j - 1);
            p_right = I2D(ncols, i, j + 1);
            p_up = I2D(ncols, i - 1, j);
            p_down = I2D(ncols, i + 1, j);

            d2tdx2 = temp_in[p_right] - 2 * temp_in[p_center] + temp_in[p_left];
            d2tdy2 = temp_in[p_down] - 2 * temp_in[p_center] + temp_in[p_up];

            temp_out[p_center] = temp_in[p_center] + thd * (d2tdx2 + d2tdy2);
        }
    }
} // fim de heat_conduction_kernel

void convert_matrix(const int nrows, const int ncols, const double *matrix_in, long *matrix_out, double precision)
{
    #pragma omp parallel for omp_num_threads = 28 omp_proc_bind = spread
    for (int i = 0; i < nrows; i++)
    {
        for (int j = 0; j < ncols; j++)
        {
            int k = i * ncols + j;
            matrix_out[k] = (long)(matrix_in[k] * precision);
        }
    }
} // fim de convert_matrix

/**
 * Escreve uma matriz em um arquivo binário.
 */
void write_matrix(const double *matrix_in, const int nrows, const int ncols, const char *filepath)
{
    const int size = nrows * ncols * sizeof(long);
    long *matrix_out = (long *)malloc(size);

    convert_matrix(nrows, ncols, matrix_in, matrix_out, PRECISION);

    FILE *file = fopen(filepath, "w");

    if (file == NULL)
    {
        perror(filepath);
        printf("\nErro na abertura do arquivo: %s\n", filepath);
        exit(EXIT_FAILURE);
    }

    int b = fwrite(matrix_out, nrows * ncols * sizeof(long), 1, file);
    if (b != 1)
    {
        perror(filepath);
        printf("\nErro na escrita do arquivo: %s\n", filepath);
        exit(EXIT_FAILURE);
    }

    fclose(file);
} // fim de write_matrix

/**
 * Lê os dados de entrada a partir de um arquivo binário.
 */
double *read_data(int *nrows, int *ncols, int *niter)
{
    int b;

    b = fread(nrows, sizeof(int), 1, stdin);
    if (b != 1)
    {
        printf("\nErro na leitura do arquivo!\n");
        exit(EXIT_FAILURE);
    }

    b = fread(ncols, sizeof(int), 1, stdin);
    if (b != 1)
    {
        printf("\nErro na leitura do arquivo!\n");
        exit(EXIT_FAILURE);
    }

    b = fread(niter, sizeof(int), 1, stdin);
    if (b != 1)
    {
        printf("\nErro na leitura do arquivo!\n");
        exit(EXIT_FAILURE);
    }

    const int size = (*nrows) * (*ncols) * sizeof(double);
    double *matrix = (double *)malloc(size);
    b = fread(matrix, size, 1, stdin);
    if (b != 1)
    {
        printf("\nErro na leitura do arquivo!\n");
        exit(EXIT_FAILURE);
    }

    return matrix;
} // fim de read_data

/**
 * Exibe instruções de uso do comando.
 */
void usage(char **argv)
{
    printf("usage: %s  < <IN_FILE>\n\n", *argv);
    exit(EXIT_FAILURE);
} // fim de usage

int main(int argc, char **argv)
{
    int nrows, ncols, niter;
    double *temp1, *temp2, *temp_tmp;
    char *in_path;

    temp1 = read_data(&nrows, &ncols, &niter);
    const int size = nrows * ncols * sizeof(double);
    temp2 = (double *)malloc(size);
    memcpy(temp2, temp1, size);

    // executa niter iterações da simulação
    int iter = 0;
    while (iter < niter)
    {
        heat_conduction_kernel(nrows, ncols, THD_SILVER, temp1, temp2);

        temp_tmp = temp1;
        temp1 = temp2;
        temp2 = temp_tmp;
        iter++;
    }

    write_matrix(temp1, nrows, ncols, "heat.out");

    free(temp1);
    free(temp2);

    return EXIT_SUCCESS;
} // fim de main
